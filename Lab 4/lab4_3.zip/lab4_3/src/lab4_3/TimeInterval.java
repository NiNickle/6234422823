
package lab4_3;

class TimeInterval {
    private int hour1; 
    private int hour2; 
    private int min1; 
    private int min2; 
    private int dif; 
    public TimeInterval(int start,int stop){ 
        hour1 = start/100*60; 
        min1 = start%100+hour1; 
        hour2 = stop/100*60; 
        min2 = stop%100+hour2; 
        dif = Math.abs(min2 - min1+1440)%1440 ; 
    } 
    public int getHours(){ 
        return dif/60; 
    } 
    public int getMinutes(){ 
        return dif%60; 
    }
}
