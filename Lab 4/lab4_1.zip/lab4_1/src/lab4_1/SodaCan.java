
package lab4_1;

public class SodaCan {
    private float h,r,volume,surfaceA;
    public SodaCan(float h,float d){
        this.h=h;
        r=d/2;
    }
    public float getVolume(){
        volume=(float)(Math.PI*r*r*h);
        return volume;
    }
    public float getSurfaceArea(){
        surfaceA=(float)(2*Math.PI*r*h+2*Math.PI*r*r);
        return surfaceA;
    }
}
