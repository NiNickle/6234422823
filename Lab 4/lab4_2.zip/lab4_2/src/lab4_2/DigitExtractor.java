
package lab4_2;

class DigitExtractor {
    int num,digit;
    public DigitExtractor(int num){
        this.num=num;
    }
    public int nextDigit(){
        digit=num%10;
        num=num/10;
        return digit;
    }
}
