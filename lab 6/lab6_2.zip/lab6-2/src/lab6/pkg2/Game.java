
package lab6.pkg2;

import java.util.*;

class Game {
    private int playerSc=0;
    private int comSc=0;
    public void play() {
        while(Math.abs(playerSc-comSc)!=2){
            Scanner input = new Scanner(System.in);
            String player = input.next();

            if(player!="0"||player!="1"||player!="2"){
                continue;
            }
            Random rand = new Random();
            int com = rand.nextInt(3);
            String enter = "";
            switch(player){
                case"0": enter="ROCK";break;
                case"1": enter="PAPER";break;
                case"2": enter="SCISSOR";
            }
            System.out.print("You enter: "+enter);
            int playerIn = Integer.parseInt(player);
            
            String comRand = "";
            switch(com){
                case 0: comRand="ROCK";break;
                case 1: comRand="PAPER";break;
                case 2: comRand="SCISSOR";
            }
            System.out.println("Computer: "+comRand);
            if(com==0 && playerIn==1 || com==1 && playerIn==2 || com==2 && playerIn==0){
                playerSc++;
                System.out.println("You win!");
            }
            else if(playerIn==0 && com==1 || playerIn==1 && com==2 || playerIn==2 && com==0){
                comSc++;
                System.out.println("You lose!");
            }
            else{System.out.println("It's a tie.");}
        }
        System.out.println("----------------------------------------");
        if(playerSc>comSc){
            System.out.println("Congrats! You win.");
        }
        else{
            System.out.println("Too bad! You lose.");
        }
        System.out.println("User Score: "+playerSc+"\nComputer score: "+comSc);
    }
}