package com.example.guessanumber;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class Game extends AppCompatActivity {
    Random rand = new Random();
    int num_rand = rand.nextInt(100)+1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        Button button = (Button) findViewById(R.id.guessBut);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gameplay();
            }
        });

    }
    public void gameplay(){
        TextView alert = (TextView) findViewById(R.id.alertText);
         EditText inputNum = (EditText) findViewById(R.id.inText);
         int num_in = Integer.parseInt(inputNum.getText().toString());
         if(num_in > num_rand) {
             alert.setText("Your guess is too high");

             inputNum.getText().clear();
         }
         else if(num_in < num_rand){
             alert.setText("Your guess is too low");
             inputNum.getText().clear();
         }
         else {
             Intent intent = new Intent(this, YouWonAc.class);
             startActivity(intent);
         }
    }
}
