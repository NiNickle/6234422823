
package lab6_3;

import java.util.Random;

class CityGrid {
    private int xCoor,yCoor,gridSize;
    private int x,y;
    public CityGrid(int x, int y){
        this.xCoor=x/2;
        this.x=x;
        this.yCoor=y/2;
        this.y=y;
        this.gridSize=x*y;
    }
    public void walk(){
        Random ran = new Random();
        int walk = ran.nextInt(4);
        if(walk==0){xCoor++;}   //right
        if(walk==1){xCoor--;}   //left
        if(walk==2){yCoor++;}   //up
        if(walk==3){yCoor--;}   //down
    }
    public boolean isInCity(){
        if ((xCoor<0||xCoor>x)||(yCoor<0||yCoor>y)){
            return false;
        }
        else{
            return true;
        }
    }
    public void reset(){
        xCoor=x/2;
        yCoor=y/2;
    }
}
