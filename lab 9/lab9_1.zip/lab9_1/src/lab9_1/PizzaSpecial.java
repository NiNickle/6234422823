
package lab9_1;

public class PizzaSpecial extends Pizza {
    private String special;
    public PizzaSpecial(String name, double prize, String special) {
        super(name,prize);
        this.special=special;
    }
    
    @Override
    public String toString(){
        return this.getName()+" price : "+this.getPrize()+" special : "+this.special+"\n";
    }
    
}
