
package lab9_1;

import java.util.ArrayList;

class Order {
    public static int cntOrder = 0; 
    private int id;
    private Customer c;
    private ArrayList<Pizza> p = new ArrayList<>();
    
    public Order(Customer customer) {
        this.c=customer;
        cntOrder++;
    }
    
     public void addPizza(Pizza pizza) {
        p.add(pizza);
    }
    
    public String getOrderDetail() {
        this.id=Order.cntOrder;
        String orderDet="Order id : "+id+"\n"+c.toString();
        for(Pizza piz:p){
            orderDet=orderDet+piz.toString();
        }
        orderDet=orderDet+"Total pieces : "+p.size()+"\nTotal cost : "+this.calculatePayment();
        return orderDet;
    }
   
    public double calculatePayment(){
        double totalPrize=0,disc=0;
        for(Pizza piz:p){
            totalPrize=totalPrize+piz.getPrize();
        }
        if(c instanceof GoldCustomer) {
            GoldCustomer goldCustomer = (GoldCustomer) c;
            disc=goldCustomer.getDiscount();
        }
        return  totalPrize=totalPrize*(100-disc)/100;
    }
    
}
