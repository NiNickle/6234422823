
package lab9_1;

class Customer {
    private String name,tel;
    Customer(String name, String tel) {
        this.name=name;
        this.tel=tel;
    }
    public String getName(){ 
        return name; 
    }
    
    public String getTel(){ 
        return tel; 
    }
    
    @Override
    public String toString(){
        return this.name+" tel : "+this.tel+"\n";
    }
    
}
