
package lab9_1;

class Pizza {
    private String name;
    private double prize;
    Pizza(String name, double prize) {
        this.name=name;
        this.prize=prize;
    }
    
    public String getName(){ 
        return name; 
    }
   
    public double getPrize(){ 
        return prize; 
    }
    
    @Override
    public String toString(){
        return this.name+" price : "+this.prize+"\n";
    }
}
