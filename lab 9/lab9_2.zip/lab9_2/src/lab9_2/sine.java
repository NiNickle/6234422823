
package lab9_2;

public class sine extends Taylor{
    public sine(int k,double x) {
        super.setIter(k);
        super.setValue(x);
    }

    @Override
    public void printValue() {
        System.out.printf("Value from Math.sine() is %.16f.\n",Math.sin(super.getValue()));
        System.out.printf("Approximated value is %.16f.\n",this.getApprox());
    }

    @Override
    public double getApprox() {
        double ans = 0;
            for(int i = 0; i<=super.getIter(); i++)
		ans += (Math.pow(-1, i) * Math.pow(super.getValue(), 2*i+1)) / super.factorial(2*i+1);
	return ans;
    }
}
