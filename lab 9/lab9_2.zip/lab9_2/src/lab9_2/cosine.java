
package lab9_2;

public class cosine extends Taylor{
    public cosine(int k,double x) {
        super.setIter(k);
        super.setValue(x);
    }

    @Override
    public void printValue() {
        System.out.printf("Value from Math.cos() is %.16f.\n",Math.cos(super.getValue()));
        System.out.printf("Approximated value is %.16f.\n",this.getApprox());
    }

    @Override
    public double getApprox() {
        double ans=0;
        for(int i=0;i<=super.getIter();++i)
            ans+=(Math.pow(-1, i)*Math.pow(super.getValue(), 2*i))/super.factorial(2*i);
        return ans;
    }
}
