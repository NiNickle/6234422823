
package lab9_2;

public class expo extends Taylor{
    public expo(int k,double x) {
        super.setIter(k);
        super.setValue(x);
    }

    @Override
    public void printValue() {
        System.out.printf("Value from Math.exp() is %.16f.\n",Math.exp(super.getValue()));
        System.out.printf("Approximated value is %.16f.\n",this.getApprox());
    }

    @Override
    public double getApprox() {
        double ans=0;
        for(int i = 0; i<=super.getIter(); i++)
            ans+=Math.pow(super.getValue(), i)/super.factorial(i);
        return ans;
    }
    
}
