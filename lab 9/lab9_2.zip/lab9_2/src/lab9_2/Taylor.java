package lab9_2;
public abstract class Taylor {
    private int k;
    private double x;
    public int factorial(int n){
        int result=1;
        for(int i=1;i<=n;++i)
            result*=i;
        return result;
    }
    
    public void setIter(int k){
        this.k=k;
    }

    public int getIter(){ 
        return this.k; 
    }
    
    public void setValue(double x){
        this.x=x;
    }
    
    public double getValue(){ 
        return this.x; 
    }
    public abstract void printValue();
    public abstract double getApprox();
}
