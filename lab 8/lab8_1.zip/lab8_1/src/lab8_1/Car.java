
package lab8_1;

public class Car {
    //eff=amount of gas using a mile(gallon) , gas=amount of gas left in 
    double gas,eff;
    //constructor
    public Car(double gas,double eff){
        this.gas=gas;
        this.eff=eff;
    }
    //calculate amount of gas to use from distance
    public void drive(double dist){
        if(this.gas<dist/this.eff){
            System.out.println("You cannot drive too far, please add gas");
        }
        else{
            this.gas=this.gas-(dist/eff);
        }
    }
    //set gas amount 
    public void setGas(double amount){
        this.gas=amount;
    }
    //return gas
    public double getGas(){
        return this.gas;
    }
    //return efficiency
    public double getEfficiency(){
       return this.eff;
    }
    //add gas
    public void addGas(double amount){
        this.gas=this.gas+amount;
    }
}
