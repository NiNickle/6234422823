
package lab8_1;


public class Truck extends Car{
    double M_weight,weight;
    public Truck(double gas, double eff,double weight,double M_weight) {
        super(gas, eff);
        this.M_weight=M_weight;
        if(this.weight>this.M_weight)
            this.weight=M_weight;
        else this.weight=weight; 
    }
    @Override
     public void drive(double distance){
        double  n = 1.0;
        if(weight<1)
            n=1.0;
        else if(weight<=10)
            n=1.1;
        else if(weight<=20)
            n=1.2;
        else if(weight>20)
            n=1.3;
        if((distance/super.getEfficiency())*n>super.getGas())
            System.out.println("You cannot drive too far, please add gas");
        else
            super.setGas(super.getGas()-(distance/super.getEfficiency())*n);
     }
     
}
