
package lab8_2;

public class NumericQuestion extends Question {

    public NumericQuestion(String text) {
        super(text);
    }
    
    @Override
    public boolean checkAnswer(String response){
        double resp = Double.parseDouble(response);
        double answer = Double.parseDouble(super.getAnswer());
        return (Math.abs(resp-answer)<=0.1);
    }
    
}
