
package lab8_2;

import java.util.ArrayList;

class ChoiceQuestion extends Question{
    private ArrayList<String> choice = new ArrayList<>();
    public ChoiceQuestion(String text){
        super(text);
    }
    
    public void addChoice(String choice,boolean correct){
        this.choice.add(choice);
        if(correct==true) super.setAnswer(choice);
    }
    
    @Override
    public void display(){
        System.out.println(super.getText());
        for(int i=0;i<choice.size();i++){
            System.out.println(i+1+": "+choice.get(i));
        }
    }
    
    @Override
    public boolean checkAnswer(String response){
        int answer = Integer.parseInt(response);
        return choice.get(answer-1).equalsIgnoreCase(super.getAnswer());
    }
}
