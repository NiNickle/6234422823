
package lab3_2;

public class Letter {
    private String sender,receiver,text,letter;
    public Letter(String sender,String receiver) {
        this.sender = sender;
        this.receiver = receiver;
        text = "";
    }
    public void addLine(String line){
        text = text +"\n"+line;
    }
    public String getText(){
        letter="Dear "+sender+" :\n"+text+"\n"+"\nSincerely,\n"+"\n"+receiver;
        return letter;
    }
    
}
