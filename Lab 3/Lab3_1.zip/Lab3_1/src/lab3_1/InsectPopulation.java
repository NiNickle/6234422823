
package lab3_1;

public class InsectPopulation {

    private double insectNum;
    
    public InsectPopulation(int amount) {
        insectNum = amount;
    }
    public void Breed(){
        insectNum = insectNum*2;
    }
    public void Spray(){
        insectNum = (insectNum*90)/100;
    }
    public double getNumInsect(){
        return insectNum;
    }
}

