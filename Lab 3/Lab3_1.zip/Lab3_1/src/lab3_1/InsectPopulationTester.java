
package lab3_1;

public class InsectPopulationTester {

    public static void main(String[] args) {
        
        InsectPopulation insect = new InsectPopulation(10); 
        insect.Breed();
        insect.Spray();
        System.out.printf("Number of insects : "+"%.2f\n",insect.getNumInsect());
        insect.Breed();
        insect.Spray();
        System.out.printf("Number of insects : "+"%.2f\n",insect.getNumInsect());
        insect.Breed();
        insect.Spray();
        System.out.printf("Number of insects : "+"%.2f\n",insect.getNumInsect());
        
    }
    
}
