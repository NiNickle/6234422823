
package lab3_3;

public class CashRegister {

    private double priceTotal,paymentTotal,fee;
    
    public CashRegister(double fee){
        this.fee = fee;
    }
    public void recordPurchase(double amount) {
        priceTotal += amount;
    }
    public void recordTaxablePurchase(double amount) {
        priceTotal += (amount*(100+fee))/100;
    }
    public double getTotalTax(){
        double tax = priceTotal*fee/100;
        return tax;
    } 
    public void enterPayment(double payment) {
        paymentTotal += payment;
    }
    public double giveChange(){
        double change= paymentTotal-priceTotal;
        priceTotal=0;
        paymentTotal=0;
        return change;
    }
    
}
