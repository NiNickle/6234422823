
package lab3_3;

public class CashRegisterTester {

    public static void main(String[] args) {
        CashRegister cashReg = new CashRegister(7);
        cashReg.recordPurchase(50);
        cashReg.recordPurchase(10);
        cashReg.recordTaxablePurchase(20);
        cashReg.enterPayment(100);
        System.out.printf("Your change is "+"%.1f\n",cashReg.giveChange());
        
        
    }
    
}
