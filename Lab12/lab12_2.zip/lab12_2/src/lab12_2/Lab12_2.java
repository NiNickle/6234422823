
package lab12_2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Lab12_2 {

    public static void main(String[] args) {
        
            File wordFile = new File("wordlist.txt");
        try{    
            Scanner in = new Scanner(wordFile);
            ArrayList<String> wordlist = new ArrayList<String>();
            while(in.hasNext())
                wordlist.add(in.nextLine());
            in.close();
        
            System.out.print("Enter a sentence: ");
            Scanner input = new Scanner(System.in);
            String[] sentence = input.nextLine().split(" ");
            ArrayList<String> doesNotContain = new ArrayList<String>() ;
        
            for(int i=0; i<sentence.length; ++i){
                for(int j=0; j<wordlist.size(); ++j){
                    if(sentence[i].equalsIgnoreCase(wordlist.get(j)))
                        break;
                    if(j==wordlist.size()-1)
                        doesNotContain.add(sentence[i]);
                }
            }
            System.out.println("Words not contained:");
            if(doesNotContain.size()<1){
                System.out.println("N/A");
            }
            int n=0;
            while(n<doesNotContain.size()){
                System.out.println(doesNotContain.get(n));
                n++;
            }
        }
        catch(FileNotFoundException e){
            System.out.println(e);
        }
    }
    
}
