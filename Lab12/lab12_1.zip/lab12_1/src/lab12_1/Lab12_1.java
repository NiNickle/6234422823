
package lab12_1;

import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;

public class Lab12_1 {
    public static void main(String[] args) 
            throws Exception
    {
        File inputFile = new File("lab12_1.txt");       
        PrintWriter output = new PrintWriter(inputFile);
        Scanner in =new Scanner(System.in);
        String inputText=in.nextLine();
        while(!inputText.equalsIgnoreCase("quit"))
        {
           output.println(inputText);
           inputText=in.nextLine();
        }
        output.close();
        int totalWord=0, totalChar=0, totalLine=0;
        Scanner input = new Scanner(inputFile);
        while(input.hasNextLine())
        {
            String line = input.nextLine();
            if (!line.equalsIgnoreCase("")) {
                totalChar+=line.length();
                totalWord += line.split(" ").length;
            }
            totalLine++;
        }
        System.out.println("Total character : "+totalChar);
        System.out.println("Total words : "+totalWord);
        System.out.println("Total lines : "+totalLine);
        input.close();
    }
    
}
