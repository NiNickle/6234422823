
package lab12_3;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.RandomAccess;
import java.util.Scanner;

public class FileMatch {
    public static void main(String[] args) throws FileNotFoundException, IOException{
        
        try( RandomAccessFile file = new RandomAccessFile("newMaster.dat","rw");)
        {
            Scanner master = new Scanner(new File("master.txt"));
            Scanner trans = new Scanner(new File("trans.txt"));
            ArrayList<AccountRecord> acctRec = new ArrayList<>();
            ArrayList<TransactionRecord> transRec = new ArrayList<>();
            
            while(master.hasNextLine()&&master.hasNext()){
                int acctNum = Integer.parseInt(master.next());
                String name = master.next();
                String lastname = master.next();
                double balance = Double.parseDouble(master.next());
                AccountRecord acc = new  AccountRecord(acctNum,name+" "+lastname,balance);
                acctRec.add(acc);
            }
            
            while(trans.hasNextLine()&&trans.hasNext()){
                int acctNum = Integer.parseInt(trans.next());
                double amount = Double.parseDouble(trans.next());
                TransactionRecord tran = new  TransactionRecord(acctNum,amount);
                transRec.add(tran);
            }
            acctRec.forEach((acc) ->
            {transRec.stream().filter((tran) -> 
                    (acc.getAcctNo()==tran.getAccountNumber())).forEach((tran) ->
                {
                    acc.combine(tran);
                });
            });
            for(AccountRecord acc: acctRec){
                String n = acc.getName();
                for(int i = 0;i<=30-acc.getName().length();++i)
                    n+="";
                file.writeInt(acc.getAcctNo());
                file.writeChars(n);
                file.writeDouble(acc.getBalance());
                file.writeInt(acc.getTransCnt());
            }
            
            double totalBalance = 0;
            int no_trans = 0;
            int totalAcc = 0;
            
            for(int i=0;i<file.length();i+=76) {
                totalAcc ++;
                file.seek(i+64);
                totalBalance += file.readDouble();
                if(file.readInt()==0) 
                    no_trans++;
            }
            
            System.out.println("Total Account Record : "+totalAcc);
            System.out.println("Total balance : "+totalBalance);
            System.out.println("No transaction : "+no_trans+" account ");
            
        }
        catch(IOException e){
            System.out.println(e);
        }
       
        
    
    }
}
