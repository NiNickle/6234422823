
package lab12_3;

public class TransactionRecord {
    private int acctNo;
    private double amount_of_transac;
    
    public TransactionRecord(int accNo, double amount){
        this.acctNo=accNo;
        this.amount_of_transac=amount;
    }
    public int getAccountNumber() {
        return acctNo;
    }

    public double getAmount() {
        return amount_of_transac;
    }
}
