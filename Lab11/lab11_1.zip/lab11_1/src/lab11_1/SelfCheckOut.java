
package lab11_1;

import java.util.ArrayList;

public class SelfCheckOut implements SimpleQueue{
    private ArrayList<Product> self = new ArrayList<>();
    private double totalPrice;
    
    @Override
    public void enqueue(Object o) {
        self.add((Product)o);
        System.out.println(((Product)o).getName()+" is added in queue");
    }

    @Override
    public void dequeue() {
        totalPrice+=(self.get(0)).getPrice();
        self.remove(0);
    }

    public double getAmount() {
         return totalPrice;
    }
    
}
