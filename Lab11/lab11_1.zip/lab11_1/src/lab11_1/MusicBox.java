
package lab11_1;

import java.util.ArrayList;

public class MusicBox implements SimpleQueue{
    private ArrayList playlist = new ArrayList<>();
    
    @Override
    public void enqueue(Object o) {
        playlist.add(o);
        System.out.println(o.toString()+" is added in queue");
    }

    @Override
    public void dequeue() {
         System.out.println("Now playing "+playlist.get(0).toString());
         playlist.remove(0);
    }

    
    
    
}
