
package lab7_1;

import java.util.ArrayList;

public class Purse {
    private ArrayList purse;
    private ArrayList rpurse;
    private ArrayList check;
    
    public Purse() {
        purse = new ArrayList<String>();
        rpurse = new ArrayList<String>();
    }
    
    public void addCoin(String coinName){
        purse.add(coinName);
    }
    @Override
    public String toString(){
        //return string Purse[] if has no value
        if (purse.size() == 0){ 
            return "Purse[]"; 
        }
        //return string Purse[a,b,c,d]
        String output = "Purse[";
        for (Object coin : purse){
            output = output + coin + ",";
        }
        // remove last ", " 
        output = output.substring(0, output.length() - 1);
        return output + "]";
    }
    
    public ArrayList<String> reverse(){
        for(int i=purse.size()-1;i>=0;i--){
           rpurse.add((String) purse.get(i));
        }
        purse=rpurse;
        return purse;
    }

    public void transfer(Purse other){
        for(Object coin : this.purse){
            other.purse.add(coin);
        }
        this.purse.clear();  
    }
    
    public boolean sameContents(Purse other){
        boolean eq = true;
        if(purse.size()==other.purse.size()){
            for(int i=0;i<purse.size();i++){
                eq=purse.get(i).equals(other.purse.get(i));
            }
        }
        else eq=false; 
        return eq;
    }
    
    public boolean sameCoins(Purse other){
        check=(ArrayList) other.purse.clone();
        boolean eq=true;
        if(purse.size()==other.purse.size()){
            for(int i=0;i<purse.size();i++){
                //if equals, remove check[j] and set remove=true
                boolean remove=false;
                for(int j=0;j<other.purse.size()&&!remove;j++){
                   check.remove(j);
                   remove=true;
                }
                if(!remove)eq=false;
            }
        }
        else eq=false; 
        return eq;
    }
 
}

