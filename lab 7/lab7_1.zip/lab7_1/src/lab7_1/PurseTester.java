
package lab7_1;

public class PurseTester {

    public static void main(String[] args) {
        Purse a = new Purse();
        a.addCoin("Nickel");
        a.addCoin("Quater");
        a.addCoin("Nickel");
        a.addCoin("Dime");
        System.out.println("A : "+a.toString());
        
        Purse b = new Purse();
        b.addCoin("Quater");
        b.addCoin("Dime");
        b.addCoin("Nickel");
        b.addCoin("Nickel");
        System.out.println("B : "+b.toString());
        System.out.println("Same coins : "+a.sameCoins(b));
        System.out.println("Same content : "+a.sameContents(b));
        
        System.out.println("----B reverse");
        b.reverse();
        System.out.println("B : "+b.toString());
        
        System.out.println("Same coins : "+a.sameCoins(b));
        System.out.println("Same content : "+a.sameContents(b));
        
        a.transfer(b);
        System.out.println("----Transfer");
        System.out.println("A : "+a.toString());
        System.out.println("B : "+b.toString());
        System.out.println("Same coins : "+a.sameCoins(b));
        System.out.println("Same content : "+a.sameContents(b));
        
        Purse c = new Purse();
        Purse d = new Purse();
        d.addCoin("Quater");
        d.addCoin("Dime");
        d.addCoin("Dime");
        d.addCoin("Nickel");
        System.out.println("C : "+c.toString());
        System.out.println("D : "+d.toString());
        System.out.println("Same coins : "+c.sameCoins(d));
        System.out.println("Same content : "+c.sameContents(d));
        
        c.addCoin("Dime");
        System.out.println("Same coins : "+c.sameCoins(d));
        System.out.println("Same content : "+c.sameContents(d));
        
    }
    
}
