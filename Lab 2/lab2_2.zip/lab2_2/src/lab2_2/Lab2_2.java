/*
Nichaphat Chawananukul Student ID: 6234422823
 */
package lab2_2;
public class Lab2_2 {
    
    public static void main(String[] args) {
        String text="Hello, World!";
        String newText=text.replace("o", "y").replace("e", "o").replace("y", "e");
        System.out.print(newText+"\n");
    }
    
}
