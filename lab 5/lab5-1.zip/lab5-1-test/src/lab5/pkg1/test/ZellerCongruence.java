
package lab5.pkg1.test;

class ZellerCongruence {
    int year,m,q;
    public ZellerCongruence(int year, int month, int day){
        this.year = year;
        this.m = month;
        this.q = day;
    }
    
    public enum Day{
        SUNDAY("Sunday"), MONDAY("Monday"), TUESDAY("Tuesday"), WEDNESDAY("Wednesday"), THURSDAY("Thursday"), FRIDAY("Friday"), SATURDAY("Saturday");
        private final String day;
        public final String dayValue;
        Day(String day){
            this.day = day;
            this.dayValue = day;
        }
        public String getdayofweekstr(){
            return dayValue;
        }
    }
  
    public Day getDayOfWeek(){
        if (m == 1){
            m=13;
            year--; 
        }
        if (m == 2) {
            m=14;
            year--; 
        }
        int k = year % 100; 
        int j = year / 100; 
        int h = (q + (13*(m + 1) / 5 )+ k + (k / 4) + (j / 4) + (5 * j))%7 ;
        Day day = null;
        switch (h) 
        {  
            case 0 : day = Day.SATURDAY; break; 
            case 1 : day = Day.SUNDAY; break;  
            case 2 : day = Day.MONDAY; break; 
            case 3 : day = Day.TUESDAY; break; 
            case 4 : day = Day.WEDNESDAY; break; 
            case 5 : day = Day.THURSDAY; break; 
            case 6 : day = Day.FRIDAY; break; 
        }
        return day;
    }    
}
