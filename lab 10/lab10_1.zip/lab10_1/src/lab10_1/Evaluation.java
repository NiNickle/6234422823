
package lab10_1;

public interface Evaluation {

    double evaluate();
//  public abstract char grade(double); 
    char grade(double eva);   
}
