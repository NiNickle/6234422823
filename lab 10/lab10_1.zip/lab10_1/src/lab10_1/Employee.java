
package lab10_1;

public class Employee {
    private String name;
    private int salary;
    public Employee(String n,int s){
        this.name=n;
        this.salary=s;
    }
    public void setSalary(int s){
        this.salary=s;
    }
    @Override
    public String toString(){
        return this.name+"\nsalary = "+this.salary; 
    }
}
