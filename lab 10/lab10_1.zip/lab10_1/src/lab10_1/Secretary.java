
package lab10_1;

public class Secretary extends Employee implements Evaluation{
    private int typingSpeed;
    private int[] score;
    public Secretary(String name, int salary , int[] sc, int tp) {
        super(name,salary);
        this.score=sc;
        this.typingSpeed=tp;
    }

    @Override
    public double evaluate() {
       double sum=0.0;
       for(int s : score)
           sum+=s;
       return sum;
    }

    @Override
    public char grade(double evaluate) {
        if(evaluate>=90){
            this.setSalary(18000);
            return 'P'; 
        }
        return 'F';
    }

    
    
}
