
package lab10_1;

public class Subject implements Evaluation{
    private String subjName;
    private final int[] score;
    public Subject(String name, int[] score) {
        this.subjName=name;
        this.score=score;
    }
    
    @Override
    public double evaluate() {
        double sum=0.0;
        for(int s : score)
           sum+=s;
        double ave=sum/score.length;
        return ave;
    }

    @Override
    public char grade(double evaluate ) {
        if(evaluate>=70)
            return 'P';
        return 'F';
    }
    
    @Override 
    public String toString(){
            return this.subjName;
    }
    
}
