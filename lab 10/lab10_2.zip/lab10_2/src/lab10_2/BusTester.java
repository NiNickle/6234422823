
package lab10_2;

import java.util.ArrayList;

public class BusTester {

    public static void main(String[] args) {
        ArrayList<Bus> arr = new ArrayList<>();
        Hybrid Hyb=new Hybrid(45,1_200_000,600,150,1);
        CNGBus CNGb=new CNGBus(50,1_000_000,200,2);
        
        arr.add(Hyb);
        arr.add(CNGb);
        
        for(Bus b: arr){
            System.out.println("ID: " + b.getID());
            int emisTier=0;
            if(b instanceof Hybrid){
                Hybrid hyBus=(Hybrid) b;
                emisTier=hyBus.getEmissionTier();
            }
            else if(b instanceof CNGBus){
                CNGBus cngBus=(CNGBus) b;
                emisTier=cngBus.getEmissionTier();
            }
            System.out.println("Emission Tier: "+emisTier);
            System.out.println("Accel: "+b.getAccel());
        }
    }
}
